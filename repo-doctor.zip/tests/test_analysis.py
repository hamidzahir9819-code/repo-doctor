from repo_doctor.analysis import (
    activity_score, bus_factor_score, health_score, license_score,
    total,
)


def test_activity_score_recent():
    from datetime import datetime, timezone
    pushed = datetime.now(timezone.utc).isoformat()
    assert activity_score(pushed) == 25


def test_activity_score_old():
    assert activity_score("2020-01-01T00:00:00Z") == 0


def test_license_score():
    assert license_score({"license": {"spdx_id": "MIT"}}) == 20
    assert license_score({}) == 0


def test_bus_factor():
    assert bus_factor_score([1, 2, 3]) == 15
    assert bus_factor_score([1]) == 0


def test_total():
    assert total({"a": 25, "b": 20, "c": 15, "d": 15, "e": 15}) == 90
