import pytest

from repo_doctor.github import parse_repo


def test_parse_slug():
    assert parse_repo("pallets/flask") == "pallets/flask"


def test_parse_url():
    assert parse_repo("https://github.com/pallets/flask/") == "pallets/flask"


def test_parse_invalid():
    with pytest.raises(ValueError):
        parse_repo("not-a-repo")
