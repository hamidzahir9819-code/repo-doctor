# Contributing to repo-doctor

Thanks for your interest! This project welcomes contributions of all sizes.

## Getting started

1. Fork the repository
2. Clone your fork: `git clone https://github.com/<you>/repo-doctor`
3. Create a branch: `git checkout -b my-feature`
4. Install in dev mode: `pip install -e .[dev]`
5. Run tests: `pytest`

## Guidelines

- Run `pytest` before opening a PR — all tests must pass
- Keep changes focused; one feature or fix per PR
- Open an issue first for large changes so we can discuss the design

## Code of conduct

Be kind and constructive. We follow the
[Contributor Covenant](https://www.contributor-covenant.org/).
