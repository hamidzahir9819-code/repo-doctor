"""Health-score computation for repo-doctor."""

from datetime import datetime, timezone


def activity_score(pushed_at, days_window=90):
    """25 points if the repo was pushed to within `days_window` days."""
    if not pushed_at:
        return 0
    pushed = datetime.fromisoformat(pushed_at.replace("Z", "+00:00"))
    age_days = (datetime.now(timezone.utc) - pushed).days
    if age_days <= days_window:
        return 25
    if age_days <= 365:
        return 10
    return 0


def license_score(info):
    return 20 if info.get("license") else 0


def ci_score(workflows):
    return 15 if workflows else 0


def bus_factor_score(contributors, min_contributors=3):
    """15 points when at least `min_contributors` people contribute."""
    return 15 if len(contributors) >= min_contributors else 0


def responsiveness_score(issues, max_score=25):
    """Heuristic: reward repos whose recent open issues are not stale.

    Simple v0.1 rule: 25 points if fewer than half of open issues are
    older than 90 days without comments. Refined in future versions.
    """
    now = datetime.now(timezone.utc)
    if not issues:
        return max_score  # no open issues -> nothing waiting
    recent = 0
    for issue in issues:
        created = datetime.fromisoformat(
            issue["created_at"].replace("Z", "+00:00"))
        if (now - created).days <= 90:
            recent += 1
    ratio = recent / len(issues)
    return round(max_score * min(1.0, ratio + 0.4))


def health_score(info, issues, contributors, workflows):
    return {
        "activity": activity_score(info.get("pushed_at")),
        "responsiveness": responsiveness_score(issues),
        "license": license_score(info),
        "ci": ci_score(workflows),
        "bus_factor": bus_factor_score(contributors),
    }


def total(scores):
    return sum(scores.values())
