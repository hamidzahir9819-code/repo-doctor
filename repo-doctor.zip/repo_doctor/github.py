"""GitHub API client for repo-doctor."""

import os
import requests

API_ROOT = "https://api.github.com"


class GitHubError(Exception):
    """Raised when a GitHub API call fails."""


def _headers():
    headers = {"Accept": "application/vnd.github+json"}
    token = os.environ.get("GITHUB_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _get(url, params=None):
    resp = requests.get(url, headers=_headers(), params=params, timeout=15)
    if resp.status_code == 404:
        raise GitHubError(f"Not found: {url}")
    if resp.status_code == 403:
        raise GitHubError("API rate limit exceeded. Set GITHUB_TOKEN.")
    resp.raise_for_status()
    return resp.json()


def parse_repo(slug_or_url):
    """Accept 'owner/repo' or a full GitHub URL and return 'owner/repo'."""
    slug = slug_or_url.strip().rstrip("/")
    if slug.startswith("https://github.com/"):
        slug = slug[len("https://github.com/"):]
    parts = slug.split("/")
    if len(parts) != 2 or not all(parts):
        raise ValueError(f"Invalid repository: {slug_or_url!r}")
    return "/".join(parts)


def repo_info(slug):
    return _get(f"{API_ROOT}/repos/{slug}")


def open_issues(slug):
    return _get(f"{API_ROOT}/repos/{slug}/issues",
                params={"state": "open", "per_page": 100})


def contributors(slug):
    return _get(f"{API_ROOT}/repos/{slug}/contributors",
                params={"per_page": 100})


def workflows(slug):
    try:
        data = _get(f"{API_ROOT}/repos/{slug}/actions/workflows")
        return data.get("workflows", [])
    except GitHubError:
        return []
