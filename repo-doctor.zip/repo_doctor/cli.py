"""Command-line interface for repo-doctor."""

import argparse
import sys

from .github import (GitHubError, contributors, open_issues, parse_repo,
                     repo_info, workflows)
from .analysis import health_score, total


def fmt_date(iso):
    return iso[:10] if iso else "unknown"


def render(slug, info, issues, contribs, wfs, scores):
    lines = [
        f"Repository: {slug}",
        f"Stars: {info.get('stargazers_count', 0):,} | "
        f"Forks: {info.get('forks_count', 0):,} | "
        f"Open issues: {len(issues)}",
        f"Last push: {fmt_date(info.get('pushed_at'))}",
        f"License: {(info.get('license') or {}).get('spdx_id', 'none')}",
        f"CI workflow: {'found' if wfs else 'not found'}",
        f"Contributors: {len(contribs)}",
        "",
        "Health breakdown:",
    ]
    for name, pts in scores.items():
        lines.append(f"  {name:<14} {pts}")
    lines.append(f"  {'TOTAL':<14} {total(scores)}/100")
    return "\n".join(lines)


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="repo-doctor",
        description="Diagnose the health of a GitHub repository.")
    parser.add_argument("repo", help="'owner/repo' or a GitHub URL")
    args = parser.parse_args(argv)

    try:
        slug = parse_repo(args.repo)
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    try:
        info = repo_info(slug)
        issues = open_issues(slug)
        contribs = contributors(slug)
        wfs = workflows(slug)
    except GitHubError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    scores = health_score(info, issues, contribs, wfs)
    print(render(slug, info, issues, contribs, wfs, scores))
    return 0


if __name__ == "__main__":
    sys.exit(main())
